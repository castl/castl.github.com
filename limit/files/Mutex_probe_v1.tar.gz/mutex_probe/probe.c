#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <assert.h>
#include <sys/types.h>
#include <unistd.h>
#include <linux/unistd.h>
#include <errno.h>
#include <execinfo.h>

#include "limit.h"
#include "probe.h"

#define REAL(F, ...)							\
    static int (*real)(__VA_ARGS__) = 0;				\
			     if (!real)					\
				 real = dlsym(RTLD_NEXT, #F);

extern const char *__progname;

// Utility func: Get the thread's PID
static pid_t gettid(void) {
    return syscall(__NR_gettid);
}

// This guy gets called for all the collected data
static void data(void* lock, enum Type type, uint64_t ev, uint64_t tsc) {
    // Get an address in the function calling the pthread_mutex_*
    // function.  Resolve this to function name at command line with:
    //    addr2line -f -e ./test 0x400ded
    // Warning: doesn't always work, depending on optimization
    void* locker = __builtin_return_address(1); 
    printf("%15s %p -- Lock: %p, ev: %10lu, tsc: %lu\n", TypeNames[type], locker, lock, ev, tsc);
}

// This is called in each thread when it is starting
static void openConn(void) {
}

// This is called in each thread when it is ending
static void closeConn(void) {
}

static void __attribute__ ((constructor)) my_init(void) {
    lprof_init(2, PERFMON_EVENTSEL_OS | EV_CYCLES,
    	       EV_CYCLES);
    openConn();
}

static void __attribute__ ((destructor)) probe_fini(void) {
    closeConn();
    lprof_close();
}


// Read the time stamp counter
#define rdtsc(X)					\
    asm volatile ("rdtsc;"				\
		  "shl $32, %%rdx;"			\
		  "orq %%rax, %%rdx;"			\
		  : "=d"(X)				\
		  :					\
		  : "%rax");


extern int limit_pthread_create(pthread_t *newthread,
				const pthread_attr_t *attr,
				void *(*start_routine) (void *),
				void *arg);

typedef struct {
    void* (*user_routine)(void*);
    void* user_args;
} user_thread;

static void* probe_thread(void* arg) {
    user_thread ut = *(user_thread*)arg;
    free(arg);

    openConn();
    void* rc = ut.user_routine(ut.user_args);
    closeConn();
    return rc;
}

extern int pthread_create (pthread_t *__restrict __newthread,
			   __const pthread_attr_t *__restrict __attr,
			   void *(*__start_routine) (void *),
			   void *__restrict __arg)
{
    user_thread* ut = NULL;

    ut = malloc(sizeof(user_thread));
    assert(ut && "Could not allocate memory.");
    ut->user_routine = __start_routine;
    ut->user_args = __arg;

    return limit_pthread_create(__newthread, __attr, probe_thread, ut);
}

void pthread_exit(void* value_ptr) {
    REAL(pthread_exit, void*);
    
    closeConn();
    real(value_ptr);
}


#define OH_BEFORE()				\
    uint64_t s, e;				\
    uint64_t st, et;				\
    rdtsc(st);					\
    lprof(1, s);

#define OH_AFTER(M,T)				\
    lprof(1, e);				\
    rdtsc(et);					\
    data(M, T, e - s, et - st);

extern int __pthread_mutex_lock (pthread_mutex_t *mutex);
int pthread_mutex_lock (pthread_mutex_t *mutex)
{
    OH_BEFORE();
    int ret = __pthread_mutex_lock(mutex);
    OH_AFTER(mutex, GET_OH);

    if (ret == 0) {
    	rdtsc(st);
    	lprof(2, s);
    	data(mutex, LOCK_ACQ_TS, s, st);
    }
    return ret;
}

extern int __pthread_mutex_unlock (pthread_mutex_t *mutex);
int pthread_mutex_unlock (pthread_mutex_t *mutex)
{
    uint64_t s1, st1;

    rdtsc(st1);
    lprof(2, s1);
    data(mutex, LOCK_RLS_TS, s1, st1);

    OH_BEFORE();
    int ret = __pthread_mutex_unlock(mutex);
    OH_AFTER(mutex, RELEASE_OH);
    return ret;
}

int pthread_mutex_trylock (pthread_mutex_t *mutex)
{
    REAL(pthread_mutex_trylock, pthread_mutex_t*);

    OH_BEFORE();
    int ret = real(mutex);
    OH_AFTER(mutex, TRY_OH);

    if (ret == 0) {
	rdtsc(st);
	lprof(2, s);
	data(mutex, LOCK_ACQ_TS, s, st);
    }
    return ret;
}

int pthread_mutex_timedlock (pthread_mutex_t *mutex,
			     const struct timespec* abstime)
{
    REAL(pthread_mutex_timedlock,
	 pthread_mutex_t*, const struct timespec* abstime);

    OH_BEFORE();
    int ret = real(mutex, abstime);
    OH_AFTER(mutex, TIMED_OH);

    if (ret == 0) {
	rdtsc(st);
	lprof(2, s);
	data(mutex, LOCK_ACQ_TS, s, st);
    }
    return ret;
}

int pthread_barrier_wait(pthread_barrier_t *b) {
    REAL(pthread_barrier_wait, pthread_barrier_t*);
    
    OH_BEFORE()
    int rc = real(b);
    OH_AFTER(b, BARRIER_WAIT)

    return rc;
}

int pthread_rwlock_rdlock(pthread_rwlock_t *m) {
    REAL(pthread_rwlock_rdlock, pthread_rwlock_t*);
    
    OH_BEFORE()
    int rc = real(m);
    OH_AFTER(m, GET_OH)

    if (rc == 0) {
	rdtsc(st);
	lprof(2, s);
	data(m, LOCK_ACQ_TS, s, st);
    }

    return rc;
}

int pthread_rwlock_tryrdlock(pthread_rwlock_t *m) {
    REAL(pthread_rwlock_tryrdlock, pthread_rwlock_t*);
    
    OH_BEFORE()
    int rc = real(m);
    OH_AFTER(m, TRY_OH)
    if (rc == 0) {
	rdtsc(st);
	lprof(2, s);
	data(m, LOCK_ACQ_TS, s, st);
    }

    return rc;
}

int pthread_rwlock_trywrlock(pthread_rwlock_t *m)  {
    REAL(pthread_rwlock_trywrlock, pthread_rwlock_t*);
    
    OH_BEFORE()
    int rc = real(m);
    OH_AFTER(m, TRY_OH)
    if (rc == 0) {
	rdtsc(st);
	lprof(2, s);
	data(m, LOCK_ACQ_TS, s, st);
    }

    return rc;
}

int pthread_rwlock_unlock(pthread_rwlock_t *m)  {
    uint64_t s, e;
    uint64_t st, et;
    REAL(pthread_rwlock_unlock, pthread_rwlock_t*);
    
    rdtsc(st);
    lprof(2, s);
    data(m, LOCK_RLS_TS, s, st);

    rdtsc(st);
    lprof(1, s);
    int rc = real(m);
    OH_AFTER(m, RELEASE_OH)

    return rc;
}

int pthread_rwlock_wrlock(pthread_rwlock_t *m) {
    REAL(pthread_rwlock_wrlock, pthread_rwlock_t*);
    
    OH_BEFORE()
    int rc = real(m);
    OH_AFTER(m, GET_OH)
    if (rc == 0) {
    	rdtsc(st);
    	lprof(2, s);
    	data(m, LOCK_ACQ_TS, s, st);
    }
    return rc;
}
