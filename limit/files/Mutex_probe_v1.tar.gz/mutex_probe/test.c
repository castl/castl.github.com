#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <limit.h>

#define NUM_THREADS     14

pthread_mutex_t mutex;
pthread_barrier_t barr;

volatile size_t a = 0;

void *PrintHello(void *threadid)
{
    size_t i;
    long tid;
    tid = (long)threadid;
    pthread_barrier_wait(&barr);
    printf("Hello World! It's me, thread #%ld!\n", tid);
    for (i=0; i<500000; i++) {
	pthread_mutex_lock(&mutex);
	a++;
	a--;
	pthread_mutex_unlock(&mutex);
	if (i % 1000 == 0)
	    pthread_barrier_wait(&barr);
    }
    pthread_exit(NULL);
}

int main (int argc, char *argv[])
{
   pthread_t threads[NUM_THREADS];
   int rc;
   long t;
   pthread_barrier_init(&barr, NULL, NUM_THREADS);
   pthread_mutex_init(&mutex, NULL);
   for(t=0; t<NUM_THREADS; t++){
      printf("In main: creating thread %ld\n", t);
      rc = pthread_create(&threads[t], NULL, PrintHello, (void *)t);
      if (rc){
         printf("ERROR; return code from pthread_create() is %d\n", rc);
         exit(-1);
      }
   }
   for(t=0; t<NUM_THREADS; t++){
      rc = pthread_join(threads[t], NULL);
      if (rc){
         printf("ERROR; return code from pthread_join() is %d\n", rc);
         exit(-1);
      }
   }

   if (a == 0)
       printf("==== PASS ====\n");
   else
       printf("==== FAIL ====\n");
   
   pthread_mutex_destroy(&mutex);
   pthread_exit(NULL);
}
