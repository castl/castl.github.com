#ifndef _PROBE_H_
#define _PROBE_H_

#include <stdint.h>

enum Type {
    INVALID,
    FOOTER,
    LOCK_ACQ_TS,
    LOCK_RLS_TS,
    TSC_CALIB,
    GET_OH,
    TRY_OH,
    TIMED_OH,
    RELEASE_OH,
    CS_TIME,
    BARRIER_WAIT,
    TYPE_MAX,
};

const char *TypeNames[] = {
    "INVALID",
    "FOOTER",
    "LOCK_ACQ_TS",
    "LOCK_RLS_TS",
    "TSC_CALIB",
    "GET_OH",
    "TRY_OH",
    "TIMED_OH",
    "RELEASE_OH",
    "CS_TIME",
    "BARRIER_WAIT",
    "TYPE_MAX"
    };

#endif
