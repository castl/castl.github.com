#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <dlfcn.h>
#include <unistd.h>
#include <stdarg.h>
#include <linux/unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "ltrace.h"
#include "limit.h"

static size_t ctr = EV_CYCLES; // Default to cycles

extern void ltrace_init(void);
extern volatile Acct acctArr[];
extern uint64_t NUM;
uint64_t lt_off1, lt_off2;

static __thread uint64_t start1, start2;
static volatile uint64_t total1 = 0, total2 = 0;
static void __attribute__ ((constructor)) my_init(void) {
    size_t i;
    char* envCtr = getenv("LT_CTR");
    if (envCtr) {
	char *nCtr;
	ctr = strtol(envCtr, &nCtr, 0);
	if (nCtr != envCtr + strlen(envCtr)) {
	    fprintf(stderr, "Bad counter specification: %s\n", getenv("LT_CTR"));
	    exit(1);
	} else {
	    //fprintf(stderr, "Counter: %lx\n", ctr);
	}
    }
    ctr &= 0xFFFF;
    lprof_init(2, PERFMON_EVENTSEL_OS | ctr, ctr);
    //lprof_init(2, PERFMON_EVENTSEL_OS | EV_CYCLES, EV_CYCLES);
    //lprof_init(2, PERFMON_EVENTSEL_OS | I7_L3_MISS, I7_L3_MISS);
    //lprof_init(2, PERFMON_EVENTSEL_OS | EV_INSTR, EV_INSTR);
    //lprof_init(2, PERFMON_EVENTSEL_OS | I7_DL1_REFS, I7_DL1_REFS);
    //lprof_init(2, PERFMON_EVENTSEL_OS | 0x30B, 0x30B);  //Mem Instrs
    //lprof_init(2, PERFMON_EVENTSEL_OS | 0x380, 0x380);  //IL1 Refs
    //lprof_init(2, PERFMON_EVENTSEL_OS | 0x185, 0x185); //ITLB Misses
    //lprof_init(2, PERFMON_EVENTSEL_OS | 0x149, 0x149); //DTLB Misses

    //lprof_init(2, PERFMON_EVENTSEL_OS | 0x800f, 0x800f);  // Uncachable
							  // for I/O

    //lprof_init(2, PERFMON_EVENTSEL_OS | 0x0480, 0x0480); //L1I Stall Cycles

    for (i=0; i<128; i++) {
	acctArr[i].total1 = 0;
	acctArr[i].total2 = 0;
	acctArr[i].count = 0;
	acctArr[i].name = NULL;
    }

    acctArr[0].name = "calloc";
    acctArr[1].name = "printf";
    acctArr[2].name = "fprintf";
    acctArr[3].name = "sprintf";
    acctArr[4].name = "snprintf";
    acctArr[5].name = "scanf";
    acctArr[6].name = "fscanf";
    acctArr[7].name = "sscanf";
    acctArr[8].name = "memset";

    ltrace_init();

    // Calibrate
    {
	uint64_t s1, s2, e1, e2;
	//Warm up
	for (i=0; i<10; i++) {
	    lprof(1, s1);
	    lprof(2, s2);
	    lprof(1, e1);
	    lprof(2, e2);
	}

	lt_off1 = (e1 - s1);
	lt_off2 = (e2 - s2);

	// Get min
	for (i=0; i<10; i++) {
	    asm volatile ("mfence;");
	    lprof(1, s1);
	    lprof(2, s2);
	    lprof(1, e1);
	    lprof(2, e2);
	    
	    if ((e1 - s1) < lt_off1)
		lt_off1 = e1 - s1;
	    if ((e2 - s2) < lt_off2)
		lt_off2 = e2 - s2;
	}
    }

    lprof(1, start1);
    lprof(2, start2);
}

extern const char *__progname;
static void __attribute__ ((destructor)) probe_fini(void) {
    size_t i;
    uint64_t end1, end2;
    char outFn[1024];

    lprof(1, end1);
    lprof(2, end2);

    __sync_fetch_and_add(&total1, end1 - start1);
    __sync_fetch_and_add(&total2, end2 - start2);

    lprof_close();

    uint64_t libcTotalUser = 0;
    uint64_t libcTotalKernel = 0;
    for (i = 0; i<NUM; i++) {
	libcTotalUser += acctArr[i].total2;
	libcTotalKernel += (acctArr[i].total1 > acctArr[i].total2 ?
			    acctArr[i].total1 - acctArr[i].total2 : 0);
    }
    
    snprintf(outFn, 1024, "/tmp/ltrace/%s-%u.csv", __progname, getpid());
    FILE* f = fopen(outFn, "w");
    if (f == NULL)
	return;
    //fprintf(stderr, "LT Out: %s\n", outFn);
    fprintf(f, "LiMiT LTrace Counter,0x%lx\n", ctr);
    fprintf(f, "Offsets,All,Userspace,Kernel\n");
    fprintf(f, ",%lu,%lu,%lu\n", lt_off1, lt_off2, (lt_off1 > lt_off2 ? lt_off1 - lt_off2 : 0));
    fprintf(f, ",Total Event Count,Total Userspace Event Count,Total Kernel Count,"
	    "Total Program,Total Libc User,Total Libc Kernel\n");
    fprintf(f, ",%lu,%lu,%lu,%lu,%lu,%lu\n", total1, total2, (total1 > total2 ? total1 - total2 : 0),
	    (total1 > libcTotalUser + libcTotalKernel ? total1 - libcTotalUser - libcTotalKernel : 0),
	    libcTotalUser, libcTotalKernel);
    fprintf(f, ",%0.2lf%%,%0.2lf%%,%0.2lf%%,%0.2lf%%,%0.2lf%%,%0.2lf%%\n",
	    100.0*total1/(double)total1,100.0*total2/(double)total1,
	    100.0*((total1 > total2 ? total1 - total2 : 0))/(double)total1,
	    100.0*((total1 > libcTotalUser + libcTotalKernel 
		    ? total1 - libcTotalUser - libcTotalKernel : 0))/(double)total1,
	    100.0*libcTotalUser/(double)total1, 100.0*libcTotalKernel/(double)total1);
    fprintf(f, "\nName,Event Count,Userspace Count,Kernel Count,Calls\n");
    for (i = 0; i<NUM; i++) {
	if (acctArr[i].name) {
	    fprintf(f, "%s,%lu,%lu,%lu,%lu\n",
		    acctArr[i].name,
		    acctArr[i].total1,
		    acctArr[i].total2,
		    (acctArr[i].total1 > acctArr[i].total2 ? acctArr[i].total1 - acctArr[i].total2 : 0),
		    acctArr[i].count);
	}
    }
    fclose(f);
}

void exit(int status) {
    REAL(int, exit, int);

    probe_fini();

    real(status);
    assert(0 && "Shit went down!");
}

pid_t fork(void) {
    pid_t rc;
    REAL(pid_t, fork);
    
    rc = real();
    if (rc == 0)
	my_init();

    return rc;
}

extern int limit_pthread_create(pthread_t *newthread,
				const pthread_attr_t *attr,
				void *(*start_routine) (void *),
				void *arg);

typedef struct {
    void* (*user_routine)(void*);
    void* user_args;
} user_thread;

static void* probe_thread(void* arg) {
    uint64_t end1, end2;
    user_thread ut = *(user_thread*)arg;
    free(arg);

    lprof(1, start1);
    lprof(2, start2);
    void* rc = ut.user_routine(ut.user_args);
    lprof(1, end1);
    lprof(2, end2);
    
    __sync_fetch_and_add(&total1, end1 - start1);
    __sync_fetch_and_add(&total2, end2 - start2);

    return rc;
}

extern int pthread_create (pthread_t *__restrict __newthread,
			   __const pthread_attr_t *__restrict __attr,
			   void *(*__start_routine) (void *),
			   void *__restrict __arg)
{
    user_thread* ut = NULL;

    ut = malloc(sizeof(user_thread));
    assert(ut && "Could not allocate memory.");
    ut->user_routine = __start_routine;
    ut->user_args = __arg;

    return limit_pthread_create(__newthread, __attr, probe_thread, ut);
}

void pthread_exit(void* value_ptr) {
    uint64_t end1, end2;
    REAL(void, pthread_exit, void*);

    lprof(1, end1);
    lprof(2, end2);
    
    __sync_fetch_and_add(&total1, end1 - start1);
    __sync_fetch_and_add(&total2, end2 - start2);
    
    real(value_ptr);
}

extern void* __libc_calloc (size_t a0, size_t a1);

void* calloc (size_t a0, size_t a1) {
    uint64_t s1, s2, e1, e2;
    void* rc;
    lprof(1, s1);
    lprof(2, s2);
    rc = __libc_calloc(a0,a1);
    lprof(1, e1);
    lprof(2, e2);
    __sync_fetch_and_add(&acctArr[0].total1, e1 - s1);
    __sync_fetch_and_add(&acctArr[0].total2, e2 - s2);
    __sync_fetch_and_add(&acctArr[0].count, 1);
    return rc;
}

int printf (const char *format, ...) {
    int rc;
    uint64_t s1, s2, e1, e2;
    lprof(1, s1);
    lprof(2, s2);
    va_list arglist;
    va_start(arglist, format);
    rc = vprintf(format, arglist);
    va_end(arglist);
    lprof(1, e1);
    lprof(2, e2);
    __sync_fetch_and_add(&acctArr[1].total1, e1 - s1);
    __sync_fetch_and_add(&acctArr[1].total2, e2 - s2);
    __sync_fetch_and_add(&acctArr[1].count, 1);
    return rc;
}

int fprintf (FILE* f, const char *format, ...) {
    int rc;
    uint64_t s1, s2, e1, e2;
    lprof(1, s1);
    lprof(2, s2);
    va_list arglist;
    va_start(arglist, format);
    rc = vfprintf(f, format, arglist);
    va_end(arglist);
    lprof(1, e1);
    lprof(2, e2);

    __sync_fetch_and_add(&acctArr[2].total1, e1 - s1);
    __sync_fetch_and_add(&acctArr[2].total2, e2 - s2);
    __sync_fetch_and_add(&acctArr[2].count, 1);
    return rc;
}

int sprintf (char* str, const char *format, ...) {
    int rc;
    uint64_t s1, s2, e1, e2;
    lprof(1, s1);
    lprof(2, s2);
    va_list arglist;
    va_start(arglist, format);
    rc = vsprintf(str, format, arglist);
    va_end(arglist);
    lprof(1, e1);
    lprof(2, e2);

    __sync_fetch_and_add(&acctArr[3].total1, e1 - s1);
    __sync_fetch_and_add(&acctArr[3].total2, e2 - s2);
    __sync_fetch_and_add(&acctArr[3].count, 1);
    return rc;
}

int snprintf (char* str, size_t size, const char *format, ...) {
    int rc;
    uint64_t s1, s2, e1, e2;
    lprof(1, s1);
    lprof(2, s2);
    va_list arglist;
    va_start(arglist, format);
    rc = vsnprintf(str, size, format, arglist);
    va_end(arglist);
    lprof(1, e1);
    lprof(2, e2);

    __sync_fetch_and_add(&acctArr[4].total1, e1 - s1);
    __sync_fetch_and_add(&acctArr[4].total2, e2 - s2);
    __sync_fetch_and_add(&acctArr[4].count, 1);
    return rc;
}

int scanf (const char *format, ...) {
    int rc;
    uint64_t s1, s2, e1, e2;
    lprof(1, s1);
    lprof(2, s2);
    va_list arglist;
    va_start(arglist, format);
    rc = vscanf(format, arglist);
    va_end(arglist);
    lprof(1, e1);
    lprof(2, e2);

    __sync_fetch_and_add(&acctArr[5].total1, e1 - s1);
    __sync_fetch_and_add(&acctArr[5].total2, e2 - s2);
    __sync_fetch_and_add(&acctArr[5].count, 1);
    return rc;
}

int fscanf (FILE* f, const char *format, ...) {
    int rc;
    uint64_t s1, s2, e1, e2;
    lprof(1, s1);
    lprof(2, s2);
    va_list arglist;
    va_start(arglist, format);
    rc = vfscanf(f, format, arglist);
    va_end(arglist);
    lprof(1, e1);
    lprof(2, e2);

    __sync_fetch_and_add(&acctArr[6].total1, e1 - s1);
    __sync_fetch_and_add(&acctArr[6].total2, e2 - s2);
    __sync_fetch_and_add(&acctArr[6].count, 1);
    return rc;
}

int sscanf (const char* str, const char *format, ...) {
    int rc;
    uint64_t s1, s2, e1, e2;
    lprof(1, s1);
    lprof(2, s2);
    va_list arglist;
    va_start(arglist, format);
    rc = vsscanf(str, format, arglist);
    va_end(arglist);
    lprof(1, e1);
    lprof(2, e2);

    __sync_fetch_and_add(&acctArr[7].total1, e1 - s1);
    __sync_fetch_and_add(&acctArr[7].total2, e2 - s2);
    __sync_fetch_and_add(&acctArr[7].count, 1);
    return rc;
}

#define op_t    unsigned long int
#define OPSIZ   (sizeof(op_t))
typedef unsigned char byte;

static void *
my_memset (dstpp, c, len)
     void *dstpp;
     int c;
     size_t len;
{
  long int dstp = (long int) dstpp;

  if (len >= 8)
    {
      size_t xlen;
      op_t cccc;

      cccc = (unsigned char) c;
      cccc |= cccc << 8;
      cccc |= cccc << 16;
      if (OPSIZ > 4)
        /* Do the shift in two steps to avoid warning if long has 32 bits.  */
        cccc |= (cccc << 16) << 16;

      /* There are at least some bytes to set.
         No need to test for LEN == 0 in this alignment loop.  */
      while (dstp % OPSIZ != 0)
        {
          ((byte *) dstp)[0] = c;
          dstp += 1;
          len -= 1;
        }

      /* Write 8 `op_t' per iteration until less than 8 `op_t' remain.  */
      xlen = len / (OPSIZ * 8);
      while (xlen > 0)
        {
          ((op_t *) dstp)[0] = cccc;
          ((op_t *) dstp)[1] = cccc;
          ((op_t *) dstp)[2] = cccc;
          ((op_t *) dstp)[3] = cccc;
          ((op_t *) dstp)[4] = cccc;
          ((op_t *) dstp)[5] = cccc;
          ((op_t *) dstp)[6] = cccc;
          ((op_t *) dstp)[7] = cccc;
          dstp += 8 * OPSIZ;
          xlen -= 1;
        }
      len %= OPSIZ * 8;

      /* Write 1 `op_t' per iteration until less than OPSIZ bytes remain.  */
      xlen = len / OPSIZ;
      while (xlen > 0)
        {
          ((op_t *) dstp)[0] = cccc;
          dstp += OPSIZ;
          xlen -= 1;
        }
      len %= OPSIZ;
    }

  /* Write the last few bytes.  */
  while (len > 0)
    {
      ((byte *) dstp)[0] = c;
      dstp += 1;
      len -= 1;
    }

  return dstpp;
}

void* memset (
    void* a0,
    int a1,
    size_t a2
    ) {
    uint64_t s1, s2, e1, e2;
    void* rc;
    lprof(1, s1);
    lprof(2, s2);
    rc = my_memset(a0,a1,a2);
    lprof(1, e1);
    lprof(2, e2);
    
    if (e1 - s1 > lt_off1) {
      e1 -= s1 + lt_off1;
    } else {
      e1 = 0;
    }
    if (e2 - s2 > lt_off2) {
      e2 -= s2 + lt_off2;
    } else {
      e2 = 0;
    }
    __sync_fetch_and_add(&acctArr[8].total1, e1);
    __sync_fetch_and_add(&acctArr[8].total2, e2);
    __sync_fetch_and_add(&acctArr[8].count, 1);
    return rc;
}
