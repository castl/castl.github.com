#define _GNU_SOURCE
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <dlfcn.h>
#include <unistd.h>
#include <linux/unistd.h>

#include "limit.h"

typedef struct {
    const char* name;
    volatile uint64_t count;
    volatile uint64_t total1, total2;
} Acct;

#define REAL(R, F, ...)							\
    static R (*real)(__VA_ARGS__) = 0;					\
				  if (!real) {				\
				      real = dlsym(RTLD_NEXT, #F);	\
				      assert(real && "Undefined symbol " #F); \
				  }

