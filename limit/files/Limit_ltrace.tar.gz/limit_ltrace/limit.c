/*
 * LambdaProfiler
 *
 *   A userland performance counter-based counter profiler.  Allows
 * users with to configure performance counters and read them.  Also
 * provides a variety of userspace utilities to assist in
 * configuration, reading and accounting.
 *
 *    Copyright (C) 2010, John Demme, Columbia University
 */

#define _GNU_SOURCE
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <linux/lprof.h>
#include <limit.h>
#include <assert.h>

//From limit_asm.S -- Critical Sections
extern void __lp_sec0(void);
extern void __lp_sec1(void);
extern void __lp_sec2(void);
extern void __lp_sec3(void);
extern void __lp_sec_end(void);

__thread struct lprof_stats __lp_stats;
static int num_ctrs;
static uint32_t confs[MAX_COUNTERS];

// Register a crictical section with the kernel
static void registerCS(int i, void* b, void* e) {
    int rc;
    size_t cs_len = (uint64_t)e - (uint64_t)b;
    rc = sys_lprof_config(LPROF_DFN_CS, i, cs_len, 
			  (void*)b);
    if (rc < 0) {
	//perror("Error registering CS");
    }
}

// Initialize counters
int lprof_init(unsigned int num, ...) {
    va_list args;
    int rc = 0, ctr = 1;
    unsigned int conf;
    __lp_stats.rdpmc_inprogress = 0;
    memset(&__lp_stats, 0, sizeof(struct lprof_stats));

    //Register critical sections for first 4 counters
    registerCS(0, __lp_sec0, __lp_sec1);
    registerCS(1, __lp_sec1, __lp_sec2);
    registerCS(2, __lp_sec2, __lp_sec3);
    registerCS(3, __lp_sec3, __lp_sec_end);

    //Configure each counter, staring with 1
    va_start(args, num);
    for (ctr=1; ctr<=num; ctr++) {
	conf = va_arg(args, unsigned int);
	//printf("Configuring counter %d as %04x\n", ctr, conf);
	do {
	    conf |= PERFMON_EVENTSEL_USR;
	    confs[ctr] = conf;
	    rc = sys_lprof_config(LPROF_START, ctr, conf, &__lp_stats);
	} while (rc < 0 && errno == EBUSY);

	if (rc < 0) {
	    //perror("Error configuring counter");
	}
    }
    va_end(args);

    num_ctrs = num;

    return rc;
}

//Close each counter
void lprof_close() {
    int i;
    for (i=1; i<=num_ctrs; i++)
	sys_lprof_config(LPROF_STOP, i, 0, 0);
}

#include <dlfcn.h>
#include <pthread.h>

static int (*real_pthread_create)(pthread_t *__restrict __newthread,
				  __const pthread_attr_t *__restrict __attr,
				  void *(*__start_routine) (void *),
				  void *__restrict __arg) = NULL;

typedef struct {
    void* (*user_routine)(void*);
    void* user_args;
} user_thread;

static void* limit_thread(void* arg) {
    size_t i;
    user_thread* ut = (user_thread*)arg;
    __lp_stats.last[0] = 0;
    __lp_stats.last[1] = 0;
    __lp_stats.last[2] = 0;
    __lp_stats.last[3] = 0;
    memset(&__lp_stats, 0, sizeof(struct lprof_stats));

    //Register critical sections for first 4 counters
    registerCS(0, __lp_sec0, __lp_sec1);
    registerCS(1, __lp_sec1, __lp_sec2);
    registerCS(2, __lp_sec2, __lp_sec3);
    registerCS(3, __lp_sec3, __lp_sec_end);

    //printf("Thread registering: %p\n",  &__lp_stats);
    for (i=1; i<=num_ctrs; i++) {
	int rc = sys_lprof_config(LPROF_START, i, confs[i], &__lp_stats);
	if (rc != 0) {
	    //perror("Attempting to start counter on new thread");
	}
    }
    void* rc = ut->user_routine(ut->user_args);
    free(ut);
    lprof_close();
    return rc;
}

int limit_pthread_create (pthread_t *__restrict __newthread,
			  __const pthread_attr_t *__restrict __attr,
			  void *(*__start_routine) (void *),
			  void *__restrict __arg)
{
    user_thread* ut = NULL;
    if (!real_pthread_create) {
	real_pthread_create = dlsym(RTLD_NEXT, "pthread_create");
    }

    ut = malloc(sizeof(user_thread));
    assert(ut && "Could not allocate memory.");
    ut->user_routine = __start_routine;
    ut->user_args = __arg;

    /* printf("pthread lpc_in:  %p, %p, %p, %p\n", __newthread, __attr, __start_routine, __arg); */
    /* printf("pthread lpc_out: %p, %p, %p, %p\n", __newthread, __attr, limit_thread, ut); */
    return real_pthread_create(__newthread, __attr, limit_thread, ut);
}

