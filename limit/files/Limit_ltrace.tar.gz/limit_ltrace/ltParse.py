#!/usr/bin/python

import re
import sys

callRe = re.compile("\d*\s*([^\(\s]+)\(.*")

counts = dict()

for line in sys.stdin.readlines():
    m = callRe.match(line)
    if m:
        f = m.groups(1)[0]
        counts[f] = counts.get(f, 0) + 1

countsList = list(counts.items())
countsList.sort(key = lambda x: x[1])
countsList.reverse()
for (f,c) in countsList:
    print "%s: %s" % (f, c)

