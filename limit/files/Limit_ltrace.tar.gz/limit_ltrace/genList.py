#!/usr/bin/python

import sys

arr = []
for line in sys.stdin.readlines():
    line = line.strip()
    if len(line) > 0 and line[0] != '/':
        arr.append(line)

OFF = 128
NUM = len(arr) + OFF
print "#include \"ltrace.h\""
print "volatile Acct acctArr[%s];" % NUM
print "uint64_t NUM = %s;" % NUM
print "extern uint64_t lt_off1, lt_off2;"
print

print "void ltrace_init(void) {"
for i in range(len(arr)):
    print "\tacctArr[%s].total1 = 0;" % (i+OFF)
    print "\tacctArr[%s].total2 = 0;" % (i+OFF)
    print "\tacctArr[%s].count = 0;" % (i+OFF)
    print "\tacctArr[%s].name = \"%s\";" % (i+OFF, arr[i].split(",")[1].strip())
print "}"
print

for i in range(len(arr)):
    func = map(lambda x: x.strip(), arr[i].split(","))
    print "%s %s (" % (func[0], func[1])
    args = func[2:]
    for j in range(len(args)):
        comma = ","
        if j == len(args) - 1:
            comma = ""
        print "\t%s a%s%s" % (args[j], j, comma)
    print """\t) {
    uint64_t s1, s2, e1, e2;
    //puts("Hello from %s");
    """ % func[1]
    rc = ""
    if func[0] != "void":
        print "%s rc;" % func[0]
        rc = "rc = "
    print """ REAL(%s,%s,%s);
    lprof(1, s1);
    lprof(2, s2);
    %s real(%s);""" % (func[0], func[1], ",".join(args), rc, ",".join(map(lambda x: "a%s" % x, range(len(args)))))
    print """    lprof(1, e1);
    lprof(2, e2);
    
    if (e1 > lt_off1 + s1) {
      e1 -= s1 + lt_off1;
    } else {
      e1 = 0;
    }
    if (e2 > lt_off2 + s2) {
      e2 -= s2 + lt_off2;
    } else {
      e2 = 0;
    }
    __sync_fetch_and_add(&acctArr[%s].total1, e1);
    __sync_fetch_and_add(&acctArr[%s].total2, e2);
    __sync_fetch_and_add(&acctArr[%s].count, 1);""" % (i+OFF, i+OFF, i+OFF)

    if func[0] != "void":
        print """return rc;
}"""
    else:
        print """return; }"""

